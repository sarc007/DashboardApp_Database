-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: dashboard
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `camera_view`
--

DROP TABLE IF EXISTS `camera_view`;
/*!50001 DROP VIEW IF EXISTS `camera_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `camera_view` AS SELECT 
 1 AS `id`,
 1 AS `config_id_fld`,
 1 AS `violation_datetime_fld`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `all_tbls_id_view`
--

DROP TABLE IF EXISTS `all_tbls_id_view`;
/*!50001 DROP VIEW IF EXISTS `all_tbls_id_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `all_tbls_id_view` AS SELECT 
 1 AS `gbm_iva_id`,
 1 AS `usecase_id`,
 1 AS `site_config_id`,
 1 AS `camera_config_id`,
 1 AS `video_id`,
 1 AS `violation_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `gbm_iva_summary_view`
--

DROP TABLE IF EXISTS `gbm_iva_summary_view`;
/*!50001 DROP VIEW IF EXISTS `gbm_iva_summary_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `gbm_iva_summary_view` AS SELECT 
 1 AS `g_id`,
 1 AS `usecases_count`,
 1 AS `sites_count`,
 1 AS `cameras_count`,
 1 AS `videos_count`,
 1 AS `violations_count`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `site_view`
--

DROP TABLE IF EXISTS `site_view`;
/*!50001 DROP VIEW IF EXISTS `site_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `site_view` AS SELECT 
 1 AS `id`,
 1 AS `config_type_id`,
 1 AS `violation_datetime_fld`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `video_view`
--

DROP TABLE IF EXISTS `video_view`;
/*!50001 DROP VIEW IF EXISTS `video_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `video_view` AS SELECT 
 1 AS `id`,
 1 AS `camera_config_id`,
 1 AS `video_name_fld`,
 1 AS `datetime_fld`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `camera_view`
--

/*!50001 DROP VIEW IF EXISTS `camera_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `camera_view` AS select 1 AS `id`,1 AS `config_id_fld`,1 AS `violation_datetime_fld` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `all_tbls_id_view`
--

/*!50001 DROP VIEW IF EXISTS `all_tbls_id_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `all_tbls_id_view` AS select `g`.`ID` AS `gbm_iva_id`,`ct`.`ID` AS `usecase_id`,`c`.`ID` AS `site_config_id`,`cc`.`ID` AS `camera_config_id`,`v`.`Id` AS `video_id`,`vl`.`ID` AS `violation_id` from (((((`gbm_iva` `g` left join `configuration_type_tbl` `ct` on((`g`.`ID` = `ct`.`fk_gbm_iva_id`))) left join `configuration_tbl` `c` on((`ct`.`ID` = `c`.`config_type_id`))) left join `camera_configuration_tbl` `cc` on((`c`.`ID` = `cc`.`config_id_fld`))) left join `videos` `v` on((`cc`.`ID` = `v`.`camera_config_id`))) left join `violation_tbl` `vl` on((`v`.`Id` = `vl`.`fk_video_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `gbm_iva_summary_view`
--

/*!50001 DROP VIEW IF EXISTS `gbm_iva_summary_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `gbm_iva_summary_view` AS select `cct`.`gbm_iva_id` AS `g_id`,count(distinct `cct`.`usecase_id`) AS `usecases_count`,count(distinct `cct`.`site_config_id`) AS `sites_count`,count(distinct `cct`.`camera_config_id`) AS `cameras_count`,count(distinct `cct`.`video_id`) AS `videos_count`,count(distinct `cct`.`violation_id`) AS `violations_count` from `all_tbls_id_view` `cct` group by `cct`.`gbm_iva_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `site_view`
--

/*!50001 DROP VIEW IF EXISTS `site_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `site_view` AS select 1 AS `id`,1 AS `config_type_id`,1 AS `violation_datetime_fld` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `video_view`
--

/*!50001 DROP VIEW IF EXISTS `video_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `video_view` AS select 1 AS `id`,1 AS `camera_config_id`,1 AS `video_name_fld`,1 AS `datetime_fld` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'dashboard'
--

--
-- Dumping routines for database 'dashboard'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-11 21:27:49
