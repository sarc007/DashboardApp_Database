-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: dashboard
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `camera_configuration_tbl`
--

DROP TABLE IF EXISTS `camera_configuration_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `camera_configuration_tbl` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `folder_fid` varchar(1000) DEFAULT NULL,
  `camera_ip_fid` varchar(100) DEFAULT NULL,
  `camera_user_id` varchar(50) DEFAULT NULL,
  `camera_password_fid` varchar(50) DEFAULT NULL,
  `camera_port_no_fid` int DEFAULT '0',
  `camera_active_fid` int DEFAULT NULL,
  `config_id_fld` int NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_UNIQUE` (`ID`),
  KEY `fk_camera_config_tbl_config_tbl_idx` (`config_id_fld`),
  CONSTRAINT `fk_camera_config_tbl_config_tbl` FOREIGN KEY (`config_id_fld`) REFERENCES `configuration_tbl` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `camera_configuration_tbl`
--

LOCK TABLES `camera_configuration_tbl` WRITE;
/*!40000 ALTER TABLE `camera_configuration_tbl` DISABLE KEYS */;
INSERT INTO `camera_configuration_tbl` VALUES (5,'c:/nocamera/data','321.359.15.24','admin','admin',8888,1,6),(7,'c:/data','46579','jksasjh','snc,zm',4564,NULL,9),(9,'E:\\WindowsDashboardApp_sarc\\No_Photo_Zone\\video_for_process','OFFLINE CAMERA','','',0,1,10),(16,'c:\\data','test 1p',NULL,NULL,NULL,NULL,52),(20,'c:/data','195.229.90.117','admin','India12345',4444,1,55),(21,'E:\\GBM_DASHBOARD\\GBM Dashboard\\Face_Mask\\Face_Mask_detection_offline\\video_for_process\\','ip','','',0,1,56),(22,'E:\\GBM_DASHBOARD\\GBM Dashboard\\social-distance-detector\\video_for_process\\','OFFLINE CAMERA','','',0,1,57),(44,'E://','192.168.1.101','admin','admin',8082,1,79),(45,'E://','192.168.1.110','admin','admin',8085,1,80),(46,'e://car_speed','192.55.77.101','root','admin',8083,1,81),(47,'e://','OFFLINE CAMERA',NULL,NULL,0,1,82);
/*!40000 ALTER TABLE `camera_configuration_tbl` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-08  1:08:29
