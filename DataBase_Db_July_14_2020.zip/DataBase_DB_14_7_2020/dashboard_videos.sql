CREATE DATABASE  IF NOT EXISTS `dashboard` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `dashboard`;
-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: dashboard
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `videos`
--

DROP TABLE IF EXISTS `videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `videos` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `video_name_fld` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `video_path_fld` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `video_datetime_fld` datetime DEFAULT NULL,
  `camera_config_id` int NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Id_UNIQUE` (`Id`),
  KEY `video_datetime_idx` (`video_datetime_fld` DESC),
  KEY `FK_video_camera_config_id_idx` (`camera_config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videos`
--

LOCK TABLES `videos` WRITE;
/*!40000 ALTER TABLE `videos` DISABLE KEYS */;
INSERT INTO `videos` VALUES (1,'Violation_001','E:\\Final_Output\\0903_1\\1.avi','2020-03-11 00:02:36',44),(2,'Violation_002','E:\\Final_Output\\0903_2\\3.avi','2019-03-05 00:03:45',44),(3,'Violation_003','E:\\Final_Output\\0903_3\\1.avi','2020-03-11 01:04:32',44),(4,'Violation_006','E:\\Final_Output\\1103_2\\2.avi','2020-03-10 02:23:12',44),(7,'Violation_007','E:\\Final_Output\\1103_2\\4.avi','2020-04-04 04:21:00',44),(8,'Violation_008','E:\\Final_Output\\1103_2\\5.avi','2018-04-04 04:21:00',44),(9,'Video2_10sec','E:\\WindowsDashboardApp_sarc\\No_Photo_Zone\\video_for_processVideo2_10sec.mp4','2020-05-08 04:16:56',9),(10,'Video_18_001','E:\\Final_Output\\1103_2\\5.avi','2020-05-08 04:16:56',10),(11,'video_18_002','E:\\Final_Output\\1103_2\\5.avi','2020-05-08 04:16:56',11),(14,'mask','E:\\GBM_DASHBOARD\\GBM Dashboard\\Face_Mask\\Face_Mask_detection_offline\\video_for_process\\mask.mp4','2020-06-17 18:50:36',21),(15,'mask1','E:\\GBM_DASHBOARD\\GBM Dashboard\\Face_Mask\\Face_Mask_detection_offline\\video_for_process\\mask1.mp4','2020-06-17 19:01:58',21),(16,'testvideo2','E:\\GBM_DASHBOARD\\GBM Dashboard\\social-distance-detector\\video_for_process\\testvideo2.mp4','2020-06-17 21:57:19',22),(17,'drinking','E:\\Eating_Drinkin_Car_Speed_Videos\\eating_drinking\\eating_drinking.mp4','2020-05-18 22:22:22',45),(39,'Car Speed 10','E:\\Eating_Drinkin_Car_Speed_Videos\\car_speed\\Car_Speed_10\\Car_Speed_10.mp4','2020-05-19 23:23:23',46),(40,'Car Speed 40','E:\\Eating_Drinkin_Car_Speed_Videos\\car_speed\\Car_Speed_40\\Car_Speed_40.mp4','2020-05-20 00:24:24',46),(41,'Car Speed','E:\\Eating_Drinkin_Car_Speed_Videos\\car_speed\\Car_Speed\\Car_Speed.mp4','2020-05-20 01:01:01',46),(42,'testvideo2_10sec','E:\\GBM_Dashboard_new\\Crowd_Management_v1.0\\testvideo2_10sec.mp4','2020-05-20 01:01:01',47);
/*!40000 ALTER TABLE `videos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-14 20:15:04
